from .board2pdf_action import board2pdf
board2pdf().register()